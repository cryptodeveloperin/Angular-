(function($) {

	"use strict";

	/*==== Loader ====*/
  //$('.preloader').fadeOut(1000); // set duration in brackets

	/*$(".msearch a").click(function(){
    	$("#imaginary_container").slideToggle();
	});*/


	/* ================ Revolution Slider. ================ */
	/*if($('.tp-banner').length > 0){
		$('.tp-banner').show().revolution({
			delay:6000,
	        startheight: 550,
	        startwidth: 1170,
	        hideThumbs: 1000,
	        navigationType: 'none',
	        touchenabled: 'on',
	        onHoverStop: 'on',
	        navOffsetHorizontal: 0,
	        navOffsetVertical: 0,
	        dottedOverlay: 'none',
	        fullWidth: 'on'
		});
	}*/
  /*
	if($('.tp-banner-full').length > 0){
		$('.tp-banner-full').show().revolution({
			delay:6000,
	        hideThumbs: 1000,
	        navigationType: 'none',
	        touchenabled: 'on',
	        onHoverStop: 'on',
	        navOffsetHorizontal: 0,
	        navOffsetVertical: 0,
	        dottedOverlay: 'none',
	        fullScreen: 'on'
		});
	}
*/


	/*testimonials*/
  /*
$(document).ready(function() {
  	$(".logosWrp").owlCarousel({
	    loop:true,
		margin:10,
		nav:false,
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
				slideBy: 1,
				nav:true
			},
			700:{
				items:2,
				slideBy: 1,
				nav:true
			},
			1170:{
				items:5,
				slideBy: 1,
				nav:true
			}
		}
  	});

	});
*/


/*testimonials*/
/*
$(document).ready(function() {
  	$(".owl-carousel").owlCarousel({
	    loop:true,
		margin:10,
		nav:false,
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
				slideBy: 1,
				nav:true
			},
			400:{
				items:2,
				slideBy: 1,
				nav:true
			},
			700:{
				items:3,
				slideBy: 1,
				nav:true
			},
			1170:{
				items:6,
				slideBy: 1,
				nav:true
			}
		}
  	});

	});
*/

/*Animation*/
new WOW().init();


})(jQuery);
