export const environment = {
  production: true,
  siteURL: "http://demo.com/"
};
