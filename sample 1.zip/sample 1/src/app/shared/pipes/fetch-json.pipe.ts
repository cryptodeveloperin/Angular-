import { Pipe, PipeTransform } from '@angular/core';
import { Http }                from '@angular/http';

import 'rxjs/add/operator/map';

@Pipe({
  name: 'fetch',
  pure: false
})
export class FetchJsonPipe  implements PipeTransform {
  private cachedData: any = null;
  private cachedUrl = '';

  constructor(private http: Http) { }

  transform(url: string): any {
    if (url !== this.cachedUrl) {
      this.cachedData = null;
      this.cachedUrl = url;
      this.http.get(url)
        .map( result => result.json() )
        .subscribe( result => this.cachedData = result );
    }

    return this.cachedData;
  }
}
/* How to use this pipe. You have to mention api url that you want to fetch and display the details and the
   methion fetch after pipe so it will hit server and retrives json then it will run the ng loop
   <div *ngFor="let hero of ('heroes.json' | fetch) ">
          {{hero.name}}
   </div>
*/
