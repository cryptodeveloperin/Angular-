import { environment } from '../../environments/environment';
import { ApiConfigurations } from './apiconfigurations';

declare var $: any;

export class SiteConfigurations {
    public EnvironmentConfigurations = environment;
    public ApiConfigurations: ApiConfigurations;
    constructor() {
        //this.ApiConfigurations = new ApiConfigurations(this.EnvironmentConfigurations.siteURL);
        this.ApiConfigurations = new ApiConfigurations("http://localhost:54983/api/");        
    }
    public static LoaderCount = 1;
    public ShowLoader(): void {
        SiteConfigurations.LoaderCount++;
        $('.preloader').fadeIn(1000);
    }
    public HideLoader(): void { 
        SiteConfigurations.LoaderCount--;
        if (SiteConfigurations.LoaderCount <= 0) {
            $('.preloader').fadeOut(1000);
        }
    }
}
