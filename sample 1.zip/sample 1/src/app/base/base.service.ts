import { SiteConfigurations } from './siteconfigurations';
import { BaseResponse } from './base.response';
import { ResponseStatus } from './responsestatus';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

export class BaseService {
    public SiteConfigurations: SiteConfigurations;
    public Options: RequestOptions;
    public Http: any;
    constructor(private http: Http) {
        this.SiteConfigurations = new SiteConfigurations();
        this.Options = new RequestOptions({
            headers: new Headers({
                'Content-Type': 'application/json',
            })
        });
        this.Http = http;
    }

    public ValidateResponse(response: BaseResponse): boolean {
        var requestValidated = false;
        if(response.Status == ResponseStatus.Success){
            return true;
        }
        //we have to validate request here
        return false;;
    }

    public AuthorizeTokenHeader() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' + currentUser.token });
            return new RequestOptions({ headers: headers });
        }
    }
    public PostRequest(postData: string, url: string): Observable<BaseResponse> {
        return this.Http.post(url, postData, this.Options)
            .map((response: Response) => { return response.json(); })
            .catch(this.HandleError);
    }
    public GetRequest(url: string): Observable<BaseResponse> {
        return this.Http.get(url, this.Options)
            .map((response: Response) => { return response.json(); })
            .catch(this.HandleError);
    }
 
    private HandleError(error: Response): void {
        console.error(error);
        //return Observable.throw(error.json().error || 'Server error');
    }
    public HideLoader() {
        this.SiteConfigurations.HideLoader();
    }
    public ShowLoader() {
        this.SiteConfigurations.ShowLoader();
    }
}
