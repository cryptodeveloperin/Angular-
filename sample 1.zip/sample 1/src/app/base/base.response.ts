import { ResponseStatus } from './responsestatus';
import { Response } from '@angular/http';

export class BaseResponse extends Response {
  public Status: ResponseStatus;
  public Message: string;
  public RedirectToURL: string; 
}
