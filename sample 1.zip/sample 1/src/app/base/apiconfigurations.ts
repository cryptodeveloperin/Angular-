export class ApiConfigurations {
  public baseURL: string;
 public HomeDataURL: string = "assets/homedata.json";
  public XpertListURL: string = "Xpert/List";
  constructor(baseURL: string) {
      this.baseURL= baseURL;      
      this.HomeDataURL = baseURL + this.HomeDataURL;
      this.XpertListURL = baseURL + this.XpertListURL;
  }
}
