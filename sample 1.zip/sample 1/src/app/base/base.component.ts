import { SiteConfigurations } from './siteconfigurations';

export class BaseComponent {
  public SiteConfigurations: SiteConfigurations;
  constructor() {
    this.SiteConfigurations = new SiteConfigurations();
  }
  public ShowAlert(message: string): void {
    alert(message);
  }
  public HideLoader(){
     this.SiteConfigurations.HideLoader();
  }
  public ShowLoader(){
     this.SiteConfigurations.ShowLoader();
  }
}
