import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';

import { FrontEndRoutingModule } from './front-end-routing.module';
import { FrontEndComponent } from './front-end.component';
import { HeaderComponent, SidebarComponent, FooterComponent } from './shared'; 

@NgModule({
    imports: [
        CommonModule,
        NgbDropdownModule.forRoot(),
        FrontEndRoutingModule,
        TranslateModule
    ],
    declarations: [
        FrontEndComponent,
        HeaderComponent,
        SidebarComponent,
        FooterComponent,
    ]
})
export class FrontEndModule { }
