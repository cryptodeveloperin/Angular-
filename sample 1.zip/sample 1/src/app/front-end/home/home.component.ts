import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
//import { SiteConfigurations } from '../../base/siteconfigurations';
import { BaseComponent } from '../../base/base.component';
import { Slider, HomeData } from './models/HomeData';
import { HomeService } from './services/home.service';

import '../../../scripts/jwgSlider.js';

declare var $: any;

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
    animations: [routerTransition()]
})
export class HomeComponent extends BaseComponent implements OnInit {
    public HomePageData: HomeData;
    public HomeService: HomeService;
    //public TestConfigurations: SiteConfigurations;
    constructor(homeService: HomeService) {
        super();
        //this.HomePageData = new HomeData();
        this.ShowLoader();
        this.HomeService = homeService;
        //this.ShowAlert("Welcome to base");
        //this.TestConfigurations = new SiteConfigurations();
        //this.ShowAlert("Welcome to base");
        //this.SiteConfigurations.HideLoader();
    }
    public InsilizejQuery() {
        //this.ShowAlert("Welcome to base");
        $('.jwg_slider_module').jwgSlider('both', 400, 'auto', 5000);
        /*Online Conent*/
        $(".library-wrap").owlCarousel({
            loop: true,
            margin: 10,
            nav: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    slideBy: 1,
                    nav: true
                },
                700: {
                    items: 3,
                    slideBy: 1,
                    nav: true
                },
                1170: {
                    items: 4,
                    slideBy: 1,
                    nav: true
                }
            }
        });
        /*testimonials*/
        $(".owl-carousel").owlCarousel({
            loop: true,
            margin: 10,
            nav: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    slideBy: 1,
                    nav: true
                },
                400: {
                    items: 2,
                    slideBy: 1,
                    nav: true
                },
                700: {
                    items: 3,
                    slideBy: 1,
                    nav: true
                },
                1170: {
                    items: 6,
                    slideBy: 1,
                    nav: true
                }   
            }
        });
    }
    ngOnInit() {
        var currentClass = this;
        $(document).ready(function() {            
        });
    }
}
