import { BaseService } from '../../../base/base.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { HomeData } from '../models/HomeData';
import { Injectable } from '@angular/core';

@Injectable()
export class HomeService extends BaseService {
    constructor(http: Http) {
        super(http);
    }
    public GetHomePageData(): Observable<HomeData> {
      return this.GetRequest(this.SiteConfigurations.ApiConfigurations.HomeDataURL);
    }
}
