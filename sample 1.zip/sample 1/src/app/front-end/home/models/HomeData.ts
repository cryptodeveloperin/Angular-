import { BaseResponse } from '../../../base/base.response';

export class HomeData extends BaseResponse {
   public Slides: Slider[];
   public ContentLibraries: OnlineContentLibrary[];
}

export class Slider{
  public ImageURL: string;
  public AltText: string;
  public Title: string;
  public Description: string;
}

export class OnlineContentLibrary {
  public ImageURL: string;
  public AltText: string;
  public Title: string;
  public URL: string;
}
