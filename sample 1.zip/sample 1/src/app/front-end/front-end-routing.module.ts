import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FrontEndComponent } from './front-end.component';

const routes: Routes = [
    {
        path: '', component: FrontEndComponent,
        children: [
            { path: '', loadChildren: './home/home.module#HomeModule' },
            { path: 'xpert', loadChildren: './xpert/xpert.module#XpertModule' },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FrontEndRoutingModule { }
