import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { BaseComponent } from '../../../../base/base.component';

declare var $:any;

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent extends BaseComponent implements OnInit {

    constructor(private translate: TranslateService, public router: Router) {
        super();
        this.router.events.subscribe((val) => {
            if (val instanceof NavigationEnd && window.innerWidth <= 992) {
                //this.toggleSidebar();
            }
        });
    }

    ngOnInit() {
      $(".msearch a").click(function(){
        	$("#imaginary_container").slideToggle();
    	});
    }

}
