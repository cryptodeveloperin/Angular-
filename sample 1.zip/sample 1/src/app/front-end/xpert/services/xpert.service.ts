import { BaseService } from '../../../base/base.service';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { XpertResponse } from '../models/XpertResponse';
import { SiteConfigurations } from '../../../base/siteconfigurations';
// import { BaseResponse } from '../../../base/base.response';

@Injectable()
export class XpertService   { 
   
    private serviceBase:string;    
    private headers: Headers;
    private options:RequestOptions;
    public SiteConfigurations: SiteConfigurations;
    public Options: RequestOptions;
    public Http: any;
    
    constructor(private http: Http) {
        this.SiteConfigurations = new SiteConfigurations();
        this.Options = new RequestOptions({
            headers: new Headers({
                'Content-Type': 'application/json',
            })
        });
        this.Http = http;
    }


    public RetrieveXpertList(Location:string,Board:string):Observable<XpertResponse> {
        debugger
       let data = JSON.stringify({ "Location": Location,"Board":Board });  
        return this.Http.post("http://localhost:54983/api/Xpert/List",data,this.options)
            .map((response: Response) => {return response.json();})
            .catch(this.handleError);
    }
             
    private handleError(error: Response) {
     //   console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    } 
}
