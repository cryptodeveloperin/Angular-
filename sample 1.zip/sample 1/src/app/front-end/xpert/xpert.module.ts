import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { XpertService } from './services/xpert.service';

import { XpertRoutingModule } from './xpert-routing.module';
import { XpertComponent } from './xpert.component';

@NgModule({
  imports: [
    CommonModule,
    XpertRoutingModule
  ],
  declarations: [XpertComponent],
  providers: [XpertService]
})
export class XpertModule { }
