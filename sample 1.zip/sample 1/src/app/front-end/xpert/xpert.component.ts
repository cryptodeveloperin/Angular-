import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base/base.component';
import { XpertService } from './services/xpert.service';
import { XpertModel } from "./models/XpertModel";
import { CMSTopic } from "./models/CMSTopic";
import { CMSTopicResponse } from "./models/CMSTopicResponse";
 

declare var $: any;

@Component({
    selector: 'app-xpert',
    templateUrl: './xpert.component.html'
    // styleUrls: ['./xpert.component.scss'],
    // animations: [routerTransition()]
})
export class XpertComponent  implements OnInit {    
    
    public XpertService: XpertService;
    imageSource:string;
    sliders:CMSTopic[];
    xpertList : XpertModel[] ;
    cmsTopicData:CMSTopicResponse;

    // sliders:CMSTopic[];
    // xpertList : XpertModel[] ;
    // cmsTopicData:CMSTopicResponse;
   

     constructor( 
        private DemoxpService:XpertService){
        
     }
     
   ngOnInit() {
         this.RetrieveXpertList(null,null);
    }
   private RetrieveXpertList(Location:string,Board:string){
             this.DemoxpService.RetrieveXpertList(Location,Board).subscribe(data => {
                 debugger;
                   if(data.IsSuccess==true){ 
                         this.xpertList = data.xpertModelList;
                   }   setTimeout(function() {
                        // currentClass.InsilizejQuery();
                        // currentClass.HideLoader();
                    }, 1000);                 
                },
                error => {
                  // this.DemoxpService.handleError(error: data);
                });   
    }
}
