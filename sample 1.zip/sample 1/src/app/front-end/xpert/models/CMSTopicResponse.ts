import { CMSZone } from "./CMSZone";
export class CMSTopicResponse{
    IsSuccess:boolean;
    ErrorMessage:string;
    TopicZones:CMSZone[];
}