export class CMSTopic {
    Id:number;
    Title:string;
    Description:string;
    Link:string;
    Image:string;
    StartDate:any;
    EndDate:any;
    DisplayOrder:number;
    ZoneId:number;
    Zone:string;
    IsDeleted: boolean;
}