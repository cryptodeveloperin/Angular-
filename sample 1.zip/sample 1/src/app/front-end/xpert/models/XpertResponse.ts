import { XpertModel } from "./XpertModel";

export class XpertResponse  {
    IsSuccess:boolean;
    ErrorMessage:string;
    xpertModelList:XpertModel[];
}	


