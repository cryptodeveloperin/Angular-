import { CMSTopic } from "./CMSTopic";
export class CMSZone{
    Id:number;
    Name:string;
    Topics:CMSTopic[];
}