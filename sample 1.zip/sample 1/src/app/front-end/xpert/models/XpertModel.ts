export class XpertModel{
         Id : number;
         Category:Number;
         Specialization:string;
         UrlName:String ;
         Office :string;   
         FirstName :string;
         LastName :string;
         MiddleName :string;
         Suffix :string;
         Prefix :string;
         Email:string;
         Fax :string;
         Phone :string;
         Zipcode :string;
         State :string;
         Country :string;
         City :string;
         Street :string;
         Biography :string;
         SortOrder :number;
         IsEditorialBoardMember :boolean;
         Continent:number;
         InfoUrl:string;
         SmallThumbUrl:string;
         GetImageUrl :string;
         Name:string;        
}