export class XpertRequest{     
    public XpertListSearchModel =new XpertListSearchModel();
 }

class XpertListSearchModel{
    public Location:string;
    public Board:string;
}
