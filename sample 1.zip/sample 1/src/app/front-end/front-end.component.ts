import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BaseComponent } from '../base/base.component';


declare var $:any;

@Component({
  selector: 'app-front-end',
  templateUrl: './front-end.component.html',
  styleUrls: ['./front-end.component.scss']
})
export class FrontEndComponent extends BaseComponent implements OnInit {

  constructor(public router: Router) { super(); }

  ngOnInit() { this.HideLoader(); }

}
