import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../router.animations';
import { BaseComponent } from '../base/base.component';

@Component({
    selector: 'app-signup',
    templateUrl: './signup.component.html',
    styleUrls: ['./signup.component.scss'],
    animations: [routerTransition()]	
})
export class SignupComponent extends BaseComponent  implements OnInit {

    constructor() { super(); }

    ngOnInit() { }
}
